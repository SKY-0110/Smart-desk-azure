"""
SmartDesk - Azure Function (Python v2 programming model)

Port of the AWS Lambda orchestrator. One HTTP route:

    POST /api/ticket      ->  triage a support ticket
    GET  /api/health      ->  liveness check

Pipeline for POST /api/ticket
    1. Validate the request body
    2. Azure AI Language   key phrases, entities, sentiment   (Comprehend equivalent)
    3. Build the 13-feature vector                             (same contract as score.py)
    4. Azure ML endpoint   Random Forest -> category + score   (SageMaker equivalent)
    5. Priority rules      P1-P4                               (same rules as the Lambda)
    6. Cosmos DB           store the ticket                    (DynamoDB equivalent)
    7. Azure Communication Services email for P1/P2            (SNS equivalent)

Application settings (environment variables)
    AZURE_LANGUAGE_ENDPOINT   https://<name>.cognitiveservices.azure.com/
    AZURE_LANGUAGE_KEY
    AZURE_ML_ENDPOINT         scoring URI from the endpoint's Consume tab
    AZURE_ML_KEY              primary key from the same tab
    COSMOS_CONNECTION         Cosmos DB connection string
    COSMOS_DATABASE           default SmartDeskDB
    COSMOS_CONTAINER          default SmartDeskTickets   (partition key /ticket_id)
    ACS_CONNECTION            Communication Services connection string
    ACS_SENDER                e.g. DoNotReply@<guid>.azurecomm.net  (from a linked email domain)
    ALERT_EMAIL               who receives P1/P2 alerts

CORS is handled by the platform (az functionapp cors add), not in this code.
Handling it in both places is what broke the AWS build's preflight requests.
"""

import json
import logging
import os
import re
import uuid
from datetime import datetime, timezone

import azure.functions as func
import requests
from azure.ai.textanalytics import TextAnalyticsClient
from azure.communication.email import EmailClient
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError, ServiceRequestError
from azure.cosmos import CosmosClient
from azure.cosmos.exceptions import CosmosHttpResponseError

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

MAX_BODY_BYTES = 100_000
ENTITY_MIN_CONFIDENCE = 0.80
PRIORITY_LABELS = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}


# ════════════════════════════════════════════════════════════════════════════
#  Errors
# ════════════════════════════════════════════════════════════════════════════

class ConfigError(Exception):
    """A required application setting is missing."""


class UpstreamError(Exception):
    """A downstream Azure service (or the ML endpoint) failed."""

    def __init__(self, service, detail=""):
        super().__init__(f"{service}: {detail}")
        self.service = service


def _setting(name, default=None, required=False):
    value = os.environ.get(name, default)
    if required and not value:
        raise ConfigError(name)
    return value


# ════════════════════════════════════════════════════════════════════════════
#  Clients (created lazily, then reused across warm invocations)
# ════════════════════════════════════════════════════════════════════════════

_language_client = None
_cosmos_container = None
_email_client = None


def get_language_client():
    global _language_client
    if _language_client is None:
        _language_client = TextAnalyticsClient(
            endpoint=_setting("AZURE_LANGUAGE_ENDPOINT", required=True),
            credential=AzureKeyCredential(_setting("AZURE_LANGUAGE_KEY", required=True)),
        )
    return _language_client


def get_container():
    global _cosmos_container
    if _cosmos_container is None:
        client = CosmosClient.from_connection_string(_setting("COSMOS_CONNECTION", required=True))
        database = client.get_database_client(_setting("COSMOS_DATABASE", "SmartDeskDB"))
        _cosmos_container = database.get_container_client(_setting("COSMOS_CONTAINER", "SmartDeskTickets"))
    return _cosmos_container


def get_email_client():
    global _email_client
    if _email_client is None:
        _email_client = EmailClient.from_connection_string(_setting("ACS_CONNECTION", required=True))
    return _email_client


# ════════════════════════════════════════════════════════════════════════════
#  Step 2 - Azure AI Language
# ════════════════════════════════════════════════════════════════════════════

def analyse_text(title, description):
    """Key phrases, entities and sentiment for one ticket."""
    text = f"{title}. {description}"[:5000]
    client = get_language_client()
    try:
        kp = client.extract_key_phrases([text], language="en")[0]
        sent = client.analyze_sentiment([text], language="en")[0]
        ents = client.recognize_entities([text], language="en")[0]
    except (HttpResponseError, ServiceRequestError) as exc:
        raise UpstreamError("Azure AI Language", str(exc)) from exc

    for result in (kp, sent, ents):
        if result.is_error:
            raise UpstreamError("Azure AI Language", getattr(result.error, "code", "document error"))

    seen, phrases = set(), []
    for phrase in kp.key_phrases:
        p = phrase.lower()
        if p not in seen:
            seen.add(p)
            phrases.append(p)

    scores = sent.confidence_scores
    positive, neutral, negative = (round(scores.positive, 4), round(scores.neutral, 4),
                                   round(scores.negative, 4))
    # Azure returns three document-level scores. "mixed" exists only as a label, so it is
    # approximated as the smaller of positive/negative when the label is mixed, else 0.
    mixed = round(min(positive, negative), 4) if sent.sentiment == "mixed" else 0.0

    entities = [{"text": e.text, "type": e.category}
                for e in ents.entities if e.confidence_score >= ENTITY_MIN_CONFIDENCE]

    return {
        "key_phrases": phrases,
        "entities": entities,
        "sentiment": sent.sentiment.upper(),
        "scores": {"positive": positive, "negative": negative, "neutral": neutral, "mixed": mixed},
    }


# ════════════════════════════════════════════════════════════════════════════
#  Step 3 - feature vector (must match score.py exactly, including order)
# ════════════════════════════════════════════════════════════════════════════

CATEGORY_KEYWORDS = {
    "network":  ["vpn", "wifi", "wi-fi", "internet", "connection", "dns", "firewall", "router",
                 "ping", "latency", "bandwidth", "network", "disconnect"],
    "hardware": ["laptop", "printer", "monitor", "keyboard", "mouse", "battery", "charger",
                 "screen", "hard drive", "ssd", "webcam", "headset", "dock", "overheat"],
    "software": ["crash", "error", "install", "update", "application", "office", "outlook",
                 "teams", "windows", "slow", "freeze", "excel", "license", "licence", "bug"],
    "security": ["password", "phishing", "virus", "malware", "hack", "mfa", "breach",
                 "suspicious", "ransomware", "spam", "unauthori", "compromis"],
    "access":   ["permission", "access denied", "locked", "admin", "privilege", "folder",
                 "directory", "share", "cannot open", "no access"],
}
URGENCY_KEYWORDS = ["critical", "urgent", "down", "production", "all users", "cannot work",
                    "not working", "completely", "stopped", "breach", "ransomware",
                    "immediately", "entire team", "everyone"]
EXACT_WORDS = {"down"}  # whole-word match so "download" does not count

FEATURES = ["kw_network", "kw_hardware", "kw_software", "kw_security", "kw_access",
            "urgency_hits", "desc_len_bucket",
            "positive", "negative", "neutral", "mixed",
            "entity_count", "user_priority_hint"]


def _found(term, text):
    pattern = r"\b" + re.escape(term) + (r"\b" if term in EXACT_WORDS else "")
    return re.search(pattern, text) is not None


def build_features(ticket, nlp):
    low = f"{ticket['title']} {ticket['description']}".lower()
    f = {f"kw_{cat}": sum(1 for k in kws if _found(k, low)) for cat, kws in CATEGORY_KEYWORDS.items()}
    f["urgency_hits"] = sum(1 for k in URGENCY_KEYWORDS if _found(k, low))
    words = len(ticket["description"].split())
    f["desc_len_bucket"] = 0 if words < 30 else (1 if words < 100 else 2)
    f.update(nlp["scores"])
    f["entity_count"] = len(nlp["entities"])
    f["user_priority_hint"] = int(ticket["user_priority"][1])
    return f


# ════════════════════════════════════════════════════════════════════════════
#  Step 4 - Azure ML managed online endpoint
# ════════════════════════════════════════════════════════════════════════════

def classify_with_ml(features):
    """POST the ordered feature list to the endpoint; return (category, confidence %)."""
    url = _setting("AZURE_ML_ENDPOINT", required=True)
    key = _setting("AZURE_ML_KEY", required=True)
    vector = [float(features[name]) for name in FEATURES]
    try:
        resp = requests.post(
            url, json={"features": vector}, timeout=20,
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        )
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, str):  # some deployments return a JSON string
            data = json.loads(data)
        if "error" in data:
            raise UpstreamError("Azure ML endpoint", str(data["error"]))
        top = data["predictions"][0]
        return str(top["label"]), round(float(top["score"]) * 100, 1)
    except UpstreamError:
        raise
    except (requests.RequestException, ValueError, KeyError, IndexError, TypeError) as exc:
        raise UpstreamError("Azure ML endpoint", repr(exc)) from exc


# ════════════════════════════════════════════════════════════════════════════
#  Step 5 - priority rules (same as the Lambda function)
# ════════════════════════════════════════════════════════════════════════════

PRIORITY_RULES = {
    "Network":      lambda h: "P1" if h >= 3 else ("P2" if h >= 1 else "P3"),
    "Hardware":     lambda h: "P2" if h >= 2 else "P3",
    "Software":     lambda h: "P2" if h >= 2 else "P3",
    "Security":     lambda h: "P1" if h >= 1 else "P2",
    "Access & IAM": lambda h: "P2" if h >= 1 else "P3",
    "General IT":   lambda h: "P3",
}


def derive_priority(category, features):
    rule = PRIORITY_RULES.get(category, PRIORITY_RULES["General IT"])
    priority = rule(features["urgency_hits"])
    if features["user_priority_hint"] == 1:  # never down-prioritise a user-flagged P1
        priority = "P1"
    return priority


# ════════════════════════════════════════════════════════════════════════════
#  Steps 6 and 7 - Cosmos DB and alert email
# ════════════════════════════════════════════════════════════════════════════

def save_ticket(doc):
    try:
        get_container().create_item(body=doc)
    except CosmosHttpResponseError as exc:
        raise UpstreamError("Cosmos DB", str(exc)) from exc


def send_alert(doc):
    """Best-effort email for P1/P2. Returns True if ACS accepted the message."""
    sender = _setting("ACS_SENDER")
    recipient = _setting("ALERT_EMAIL")
    if not (sender and recipient and _setting("ACS_CONNECTION")):
        logging.warning("Alert skipped: ACS_CONNECTION, ACS_SENDER or ALERT_EMAIL is not set")
        return False

    subject = re.sub(r"[\r\n]+", " ", f"[SmartDesk {doc['priority']}] {doc['title'][:80]}")
    body = (
        f"NEW {doc['priority']} ({doc['priority_label']}) TICKET\n"
        f"{'=' * 48}\n"
        f"Ticket ID   : {doc['ticket_id']}\n"
        f"Submitted   : {doc['timestamp']}\n"
        f"From        : {doc['name']} <{doc['email']}>\n"
        f"Department  : {doc['department']}\n"
        f"Device      : {doc['device'] or 'N/A'}\n\n"
        f"Title       : {doc['title']}\n\n"
        f"Description :\n{doc['description'][:500]}\n\n"
        f"{'-' * 48}\n"
        f"AI triage   : {doc['category']} / {doc['priority']}  (confidence {doc['confidence']}%)\n"
        f"Sentiment   : {doc['sentiment']}\n"
        f"Key phrases : {', '.join(doc['key_phrases'][:5])}\n"
    )
    message = {
        "senderAddress": sender,
        "recipients": {"to": [{"address": recipient}]},
        "content": {"subject": subject, "plainText": body},
    }
    try:
        get_email_client().begin_send(message)  # request accepted; delivery completes asynchronously
        return True
    except Exception:  # alert failure must never lose a stored ticket
        logging.exception("ACS email failed for %s", doc["ticket_id"])
        return False


# ════════════════════════════════════════════════════════════════════════════
#  Step 1 - validation, and the pipeline itself
# ════════════════════════════════════════════════════════════════════════════

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
LIMITS = {"name": 100, "email": 254, "department": 100, "device": 100, "title": 200, "description": 5000}
REQUIRED = ["name", "email", "department", "title", "description"]


def validate(body):
    """Return (clean_ticket, None) or (None, error_message)."""
    clean = {}
    for field, limit in LIMITS.items():
        value = body.get(field, "")
        if value is None:
            value = ""
        if not isinstance(value, str):
            return None, f"Field '{field}' must be text"
        value = value.strip()
        if len(value) > limit:
            return None, f"Field '{field}' is too long (max {limit} characters)"
        clean[field] = value
    missing = [f for f in REQUIRED if not clean[f]]
    if missing:
        return None, f"Missing fields: {', '.join(missing)}"
    if not EMAIL_RE.match(clean["email"]):
        return None, "Field 'email' is not a valid email address"
    priority = str(body.get("user_priority", "P3")).strip().upper()
    clean["user_priority"] = priority if priority in PRIORITY_LABELS else "P3"
    return clean, None


def process_ticket(body):
    """Run the whole pipeline. Returns (http_status, payload_dict)."""
    ticket, error = validate(body)
    if error:
        return 400, {"error": error}

    ticket_id = f"TKT-{uuid.uuid4().hex[:8].upper()}"
    logging.info("Processing %s", ticket_id)

    try:
        nlp = analyse_text(ticket["title"], ticket["description"])
        features = build_features(ticket, nlp)
        category, confidence = classify_with_ml(features)
        priority = derive_priority(category, features)

        timestamp = datetime.now(timezone.utc).isoformat()
        doc = {
            "id": ticket_id,  # Cosmos DB requires "id"; the partition key is /ticket_id
            "ticket_id": ticket_id,
            "timestamp": timestamp,
            "name": ticket["name"], "email": ticket["email"], "department": ticket["department"],
            "device": ticket["device"], "title": ticket["title"], "description": ticket["description"],
            "category": category, "priority": priority, "priority_label": PRIORITY_LABELS[priority],
            "confidence": confidence, "sentiment": nlp["sentiment"],
            "key_phrases": nlp["key_phrases"][:10],
            "entities": [e["text"] for e in nlp["entities"]][:6],
            "features": features,
            "status": "OPEN",
        }
        save_ticket(doc)
        alert_sent = send_alert(doc) if priority in ("P1", "P2") else False
    except ConfigError as exc:
        logging.error("Missing application setting: %s", exc)
        return 500, {"error": "Server configuration error"}
    except UpstreamError as exc:
        logging.error("Upstream failure for %s: %s", ticket_id, exc)
        return 502, {"error": f"{exc.service} unavailable"}
    except Exception:
        logging.exception("Unexpected error for %s", ticket_id)
        return 500, {"error": "Internal error while triaging ticket"}

    return 200, {
        "ticket_id": ticket_id,
        "category": category,
        "priority": priority,
        "priority_label": PRIORITY_LABELS[priority],
        "confidence": confidence,
        "sentiment": nlp["sentiment"],
        "key_phrases": nlp["key_phrases"][:6],
        "entities": nlp["entities"][:4],
        "timestamp": timestamp,
        "alert_sent": alert_sent,
    }


# ════════════════════════════════════════════════════════════════════════════
#  HTTP triggers
# ════════════════════════════════════════════════════════════════════════════

def _json(status, payload):
    return func.HttpResponse(json.dumps(payload), status_code=status, mimetype="application/json")


@app.route(route="ticket", methods=["POST"])
def ticket(req: func.HttpRequest) -> func.HttpResponse:
    if len(req.get_body()) > MAX_BODY_BYTES:
        return _json(413, {"error": "Request body too large"})
    try:
        body = req.get_json()
    except ValueError:
        return _json(400, {"error": "Invalid JSON body"})
    if not isinstance(body, dict):
        return _json(400, {"error": "Request body must be a JSON object"})
    status, payload = process_ticket(body)
    return _json(status, payload)


@app.route(route="health", methods=["GET"])
def health(req: func.HttpRequest) -> func.HttpResponse:
    return _json(200, {"status": "ok"})
