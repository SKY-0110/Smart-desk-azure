"""
Offline tests for function_app.py.

No Azure account is needed: the Language, Cosmos DB and email clients are replaced with
fakes, and the Azure ML endpoint call is routed to the real score.py so the request/response
contract between the Function and the scoring script is exercised for real.

Run:  python test_function.py
(score.py is looked up next to this file, or one folder up, or via SCORE_PY.)
"""
import importlib.util
import json
import os
import sys
import types
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ.update({
    "AZURE_LANGUAGE_ENDPOINT": "https://fake.cognitiveservices.azure.com/",
    "AZURE_LANGUAGE_KEY": "fake-language-key",
    "AZURE_ML_ENDPOINT": "https://fake.inference.ml.azure.com/score",
    "AZURE_ML_KEY": "fake-ml-key",
    "COSMOS_CONNECTION": "AccountEndpoint=https://fake.documents.azure.com:443/;AccountKey=ZmFrZQ==;",
    "ACS_CONNECTION": "endpoint=https://fake.communication.azure.com/;accesskey=ZmFrZQ==",
    "ACS_SENDER": "DoNotReply@fake.azurecomm.net",
    "ALERT_EMAIL": "oncall@example.com",
})
sys.path.insert(0, str(HERE))
import azure.functions as func  # noqa: E402
from azure.cosmos.exceptions import CosmosHttpResponseError  # noqa: E402

import function_app as fa  # noqa: E402


def _load_score():
    candidates = [os.environ.get("SCORE_PY"), HERE / "score.py", HERE.parent / "score.py"]
    for c in candidates:
        if c and Path(c).exists():
            spec = importlib.util.spec_from_file_location("score", c)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.init()
            return mod
    raise SystemExit("score.py not found - put it next to this file or set SCORE_PY")


SCORE = _load_score()
NS = types.SimpleNamespace


class FakeLanguage:
    def __init__(self, sentiment="negative", scores=(0.02, 0.05, 0.93), error=False):
        self.sentiment, self.scores, self.error = sentiment, scores, error

    def extract_key_phrases(self, docs, language="en"):
        return [NS(is_error=self.error, error=NS(code="InvalidRequest"),
                   key_phrases=["VPN client", "vpn client", "Windows update"])]

    def analyze_sentiment(self, docs, language="en"):
        pos, neu, neg = self.scores
        return [NS(is_error=False, sentiment=self.sentiment,
                   confidence_scores=NS(positive=pos, neutral=neu, negative=neg))]

    def recognize_entities(self, docs, language="en"):
        return [NS(is_error=False, entities=[
            NS(text="Windows", category="Product", confidence_score=0.95),
            NS(text="maybe", category="Skill", confidence_score=0.40),
        ])]


class FakeContainer:
    def __init__(self, fail=False):
        self.items, self.fail = [], fail

    def create_item(self, body):
        if self.fail:
            raise CosmosHttpResponseError(status_code=503, message="unavailable")
        self.items.append(body)


class FakeEmail:
    def __init__(self, fail=False):
        self.sent, self.fail = [], fail

    def begin_send(self, message):
        if self.fail:
            raise RuntimeError("ACS down")
        self.sent.append(message)


class FakeResponse:
    def __init__(self, payload, status=200):
        self._p, self.status_code = payload, status

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"{self.status_code}")

    def json(self):
        return self._p


GOOD = {
    "name": "Test User", "email": "test@company.com", "department": "Engineering",
    "device": "Laptop", "title": "VPN not connecting after Windows update",
    "description": "Since this morning my VPN client crashes on launch. Error 0x800704CF. "
                   "Entire team affected and cannot work, this is critical.",
    "user_priority": "P2",
}


class Base(unittest.TestCase):
    def setUp(self):
        self.lang, self.container, self.email = FakeLanguage(), FakeContainer(), FakeEmail()
        self.ml_calls, self.ml_mode = [], "real"
        fa._language_client, fa._cosmos_container, fa._email_client = self.lang, self.container, self.email

        def fake_post(url, json=None, headers=None, timeout=None):
            self.ml_calls.append({"url": url, "json": json, "headers": headers, "timeout": timeout})
            if self.ml_mode == "down":
                import requests
                raise requests.ConnectionError("endpoint unreachable")
            if self.ml_mode == "error-body":
                return FakeResponse({"error": "boom"})
            out = SCORE.run(__import__("json").dumps(json))
            return FakeResponse(out)

        self._orig_post = fa.requests.post
        fa.requests.post = fake_post

    def tearDown(self):
        fa.requests.post = self._orig_post
        fa._language_client = fa._cosmos_container = fa._email_client = None


class PipelineTests(Base):
    def test_happy_path_high_priority(self):
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual(status, 200, out)
        for key in ("ticket_id", "category", "priority", "priority_label", "confidence",
                    "sentiment", "key_phrases", "entities", "timestamp", "alert_sent"):
            self.assertIn(key, out)
        self.assertTrue(out["ticket_id"].startswith("TKT-"))
        self.assertEqual(out["sentiment"], "NEGATIVE")
        self.assertEqual(out["key_phrases"], ["vpn client", "windows update"])  # lower-cased, de-duplicated
        self.assertEqual([e["text"] for e in out["entities"]], ["Windows"])      # low-confidence entity dropped
        self.assertIn(out["priority"], ("P1", "P2"))
        self.assertTrue(out["alert_sent"])
        self.assertEqual(len(self.email.sent), 1)
        # stored document
        doc = self.container.items[0]
        self.assertEqual(doc["id"], doc["ticket_id"])
        self.assertEqual(doc["status"], "OPEN")
        self.assertEqual(doc["category"], out["category"])

    def test_ml_request_contract(self):
        fa.process_ticket(dict(GOOD))
        call = self.ml_calls[0]
        self.assertEqual(call["headers"]["Authorization"], "Bearer fake-ml-key")
        vec = call["json"]["features"]
        self.assertEqual(len(vec), 13)
        stored = self.container.items[0]["features"]
        self.assertEqual(vec, [float(stored[n]) for n in fa.FEATURES])
        self.assertEqual(stored["user_priority_hint"], 2)
        self.assertEqual(stored["entity_count"], 1)
        self.assertEqual(stored["mixed"], 0.0)

    def test_low_priority_sends_no_email(self):
        self.lang.sentiment, self.lang.scores = "neutral", (0.1, 0.85, 0.05)
        status, out = fa.process_ticket({**GOOD, "title": "Question about desk booking",
                                          "description": "Where do I book a desk for next week?",
                                          "user_priority": "P4"})
        self.assertEqual(status, 200)
        self.assertEqual(out["category"], "General IT")
        self.assertEqual(out["priority"], "P3")
        self.assertFalse(out["alert_sent"])
        self.assertEqual(self.email.sent, [])
        self.assertEqual(len(self.container.items), 1)

    def test_user_p1_is_never_downgraded(self):
        status, out = fa.process_ticket({**GOOD, "title": "Desk booking", "description": "Where is my desk?",
                                          "user_priority": "P1"})
        self.assertEqual((status, out["priority"]), (200, "P1"))

    def test_security_ticket_is_critical(self):
        status, out = fa.process_ticket({**GOOD, "title": "Phishing email with malware attachment",
                                          "description": "Suspicious phishing message, possible malware and breach.",
                                          "user_priority": "P3"})
        self.assertEqual(status, 200)
        self.assertEqual(out["category"], "Security")
        self.assertEqual(out["priority"], "P1")

    def test_email_subject_cannot_inject_headers(self):
        fa.process_ticket({**GOOD, "title": "Urgent\r\nBcc: attacker@evil.com critical down"})
        subject = self.email.sent[0]["content"]["subject"]
        self.assertNotIn("\r", subject)
        self.assertNotIn("\n", subject)


class FailureTests(Base):
    def test_validation_errors(self):
        cases = [
            ({}, "Missing fields"),
            ({**GOOD, "email": "not-an-email"}, "email"),
            ({**GOOD, "title": 123}, "must be text"),
            ({**GOOD, "description": "x" * 5001}, "too long"),
            ({**GOOD, "name": "   "}, "Missing fields"),
        ]
        for body, fragment in cases:
            status, out = fa.process_ticket(body)
            self.assertEqual(status, 400, body)
            self.assertIn(fragment, out["error"])
        self.assertEqual(self.container.items, [])
        self.assertEqual(self.ml_calls, [])

    def test_bad_priority_hint_falls_back_to_p3(self):
        status, _ = fa.process_ticket({**GOOD, "user_priority": "banana"})
        self.assertEqual(status, 200)
        self.assertEqual(self.container.items[0]["features"]["user_priority_hint"], 3)

    def test_language_service_error(self):
        self.lang.error = True
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual((status, out["error"]), (502, "Azure AI Language unavailable"))
        self.assertEqual(self.container.items, [])

    def test_ml_endpoint_down_stores_nothing(self):
        self.ml_mode = "down"
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual((status, out["error"]), (502, "Azure ML endpoint unavailable"))
        self.assertEqual(self.container.items, [])

    def test_ml_endpoint_error_body(self):
        self.ml_mode = "error-body"
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual(status, 502)

    def test_cosmos_failure(self):
        self.container.fail = True
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual((status, out["error"]), (502, "Cosmos DB unavailable"))
        self.assertEqual(self.email.sent, [])

    def test_email_failure_does_not_lose_ticket(self):
        self.email.fail = True
        status, out = fa.process_ticket(dict(GOOD))
        self.assertEqual(status, 200)
        self.assertFalse(out["alert_sent"])
        self.assertEqual(len(self.container.items), 1)

    def test_missing_setting_is_generic_500(self):
        saved = os.environ.pop("AZURE_ML_KEY")
        try:
            status, out = fa.process_ticket(dict(GOOD))
        finally:
            os.environ["AZURE_ML_KEY"] = saved
        self.assertEqual((status, out["error"]), (500, "Server configuration error"))
        self.assertNotIn("AZURE_ML_KEY", json.dumps(out))

    def test_alert_skipped_when_email_not_configured(self):
        saved = os.environ.pop("ALERT_EMAIL")
        try:
            status, out = fa.process_ticket(dict(GOOD))
        finally:
            os.environ["ALERT_EMAIL"] = saved
        self.assertEqual(status, 200)
        self.assertFalse(out["alert_sent"])


class RouteTests(Base):
    @staticmethod
    def _call(builder, req):
        # @app.route returns a FunctionBuilder; the plain Python function sits inside it
        fn = builder._function.get_user_function()
        return fn(req)

    def _req(self, body: bytes, method="POST"):
        return func.HttpRequest(method=method, url="/api/ticket", body=body,
                                headers={"Content-Type": "application/json"})

    def test_route_success(self):
        resp = self._call(fa.ticket, self._req(json.dumps(GOOD).encode()))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.mimetype, "application/json")
        self.assertIn("ticket_id", json.loads(resp.get_body()))

    def test_route_rejects_bad_json(self):
        self.assertEqual(self._call(fa.ticket, self._req(b"{not json")).status_code, 400)
        self.assertEqual(self._call(fa.ticket, self._req(b"[1,2,3]")).status_code, 400)

    def test_route_rejects_oversized_body(self):
        self.assertEqual(self._call(fa.ticket, self._req(b"x" * 100_001)).status_code, 413)

    def test_health(self):
        resp = self._call(fa.health, self._req(b"", method="GET"))
        self.assertEqual(json.loads(resp.get_body()), {"status": "ok"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
