# SmartDesk - Azure Function

`function_app.py` is the Azure port of the Lambda orchestrator (Python v2 programming model).

    POST /api/ticket   triage a ticket  (Language -> Azure ML -> Cosmos DB -> email for P1/P2)
    GET  /api/health   liveness check

## 0. What you need first
A working Azure subscription. The earlier one expired, so every resource (Language, Azure ML
endpoint, Cosmos DB, Communication Services) has to be recreated there with the same steps as
before. New resources mean new keys. Nothing in this folder contains real keys.

## 1. Test offline (no Azure needed)
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python test_function.py          # 19 tests; uses fakes + the real score.py

## 2. Email sender (portal - one time)
ACS cannot send until it has a verified sender domain:
1. Create an **Email Communication Service**, add an **Azure managed domain**.
2. In your **Communication Service**, open Email > Domains > Connect, and pick that domain.
3. Copy the MailFrom address (looks like `DoNotReply@<guid>.azurecomm.net`) -> `ACS_SENDER`.

## 3. Create the Function App (Flex Consumption)
    az provider register --namespace Microsoft.Web
    az functionapp list-flexconsumption-locations --query "sort_by(@, &name)[].{Region:name}" -o table
    az storage account create --name smartdeskfuncstore --resource-group smartdesk-rg --location westus2 --sku Standard_LRS --allow-blob-public-access false
    az functionapp create --resource-group smartdesk-rg --name smartdesk-func-<unique> --storage-account smartdeskfuncstore --flexconsumption-location westus2 --runtime python --runtime-version 3.11

Pick a region from the list; the storage account must be in the same region. The app name
becomes your URL, so it must be globally unique.

## 4. Application settings
Run as one line, quoting every value (connection strings contain `;` and `=`):

    az functionapp config appsettings set --name smartdesk-func-<unique> --resource-group smartdesk-rg --settings 'AZURE_LANGUAGE_ENDPOINT=...' 'AZURE_LANGUAGE_KEY=...' 'AZURE_ML_ENDPOINT=...' 'AZURE_ML_KEY=...' 'COSMOS_CONNECTION=...' 'COSMOS_DATABASE=SmartDeskDB' 'COSMOS_CONTAINER=SmartDeskTickets' 'ACS_CONNECTION=...' 'ACS_SENDER=...' 'ALERT_EMAIL=you@example.com'

## 5. Deploy (needs Azure Functions Core Tools v4)
    func azure functionapp publish smartdesk-func-<unique>

## 6. CORS (the platform handles it, not the code)
    az functionapp cors add --name smartdesk-func-<unique> --resource-group smartdesk-rg --allowed-origins https://<your-storage>.z13.web.core.windows.net

If that command is rejected for your plan: Function App > API > CORS in the portal.
Do not add CORS headers in code as well. Doing both broke the AWS build's preflight requests.

## 7. Point the frontend at it
In index.html set:

    const API_URL = 'https://smartdesk-func-<unique>.azurewebsites.net/api/ticket';

then re-upload to the `$web` container with `--overwrite` and hard refresh.

## 8. Smoke test
    curl https://smartdesk-func-<unique>.azurewebsites.net/api/health
    curl -X POST https://smartdesk-func-<unique>.azurewebsites.net/api/ticket -H "Content-Type: application/json" -d '{"name":"Test","email":"test@company.com","department":"Engineering","title":"VPN broken","description":"VPN crashes on launch, entire team cannot work, critical","user_priority":"P2"}'

## Notes
- The route is **anonymous** because a static site cannot hold a function key safely. Anyone with
  the URL can submit tickets, as in the AWS prototype. For production, put Entra ID / Easy Auth in front.
- `score.py` is only here so the tests can run; it is excluded from deployment by `.funcignore`.
  It is deployed to Azure ML, not to the Function.
- Flex Consumption bills only while functions run, but the Azure ML endpoint bills while it exists.
  Delete it after your demo.
