"""
SmartDesk - Azure ML scoring script (managed online endpoint)

Same approach that fixed the SageMaker health-check failure on AWS:
the Random Forest is trained inside init() when the container starts,
so there is no pickle file and no scikit-learn version mismatch.

Request body (JSON):
    {"features": [13 numbers in this order]}
    kw_network, kw_hardware, kw_software, kw_security, kw_access,
    urgency_hits, desc_len_bucket,
    positive, negative, neutral, mixed,
    entity_count, user_priority_hint

Response (JSON):
    {"predictions": [{"label": "Software", "score": 0.87}]}
"""

import json
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

model = None
le = None

PROFILES = {
    "Network":      [3, 0, 1, 0, 0, 1, 1, 0.05, 0.70, 0.20, 0.05, 2, 2],
    "Hardware":     [0, 3, 1, 0, 0, 1, 1, 0.10, 0.55, 0.30, 0.05, 2, 3],
    "Software":     [0, 0, 4, 0, 1, 1, 1, 0.05, 0.65, 0.25, 0.05, 2, 3],
    "Security":     [0, 0, 0, 4, 2, 2, 1, 0.02, 0.85, 0.10, 0.03, 3, 1],
    "Access & IAM": [0, 0, 1, 1, 3, 1, 1, 0.05, 0.60, 0.30, 0.05, 2, 2],
    "General IT":   [0, 0, 1, 0, 0, 0, 1, 0.20, 0.35, 0.40, 0.05, 1, 3],
}


def init():
    """Runs once when the container starts."""
    global model, le
    np.random.seed(42)

    rows, labels = [], []
    for cat, base in PROFILES.items():
        for _ in range(100):
            row = []
            for b in base:
                if isinstance(b, int):
                    row.append(max(0, b + int(np.random.randint(-1, 2))))
                else:
                    row.append(max(0.0, round(b + float(np.random.uniform(-0.1, 0.1)), 4)))
            rows.append(row)
            labels.append(cat)

    le = LabelEncoder()
    y = le.fit_transform(labels)

    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        class_weight="balanced",
        random_state=42,
    )
    model.fit(rows, y)


def run(raw_data):
    """Runs on every request."""
    try:
        data = json.loads(raw_data)
        features = [float(x) for x in data["features"]]
        if len(features) != 13:
            return {"error": f"Expected 13 features, got {len(features)}"}

        proba = model.predict_proba([features])[0]
        idx = int(np.argmax(proba))
        label = str(le.inverse_transform([idx])[0])

        return {"predictions": [{"label": label, "score": float(proba[idx])}]}
    except Exception as exc:
        return {"error": str(exc)}
